package onlineAppointmentSystem;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

public class AppointmentSystems
   {
    private static final String JDBC_URL = "jdbc:mysql://localhost:3306/mydb";
    private static final String JDBC_USER = "your_db_username";
    private static final String JDBC_PASSWORD = "your_db_password";

    public static void main(String[] args) 
    {
        Scanner scanner = new Scanner(System.in);
        
        System.out.println("Welcome to the Appointment Scheduling System!");
        System.out.println("1. Register\n2. Login\n3. Exit");
        System.out.print("Enter your choice: ");
        int choice = scanner.nextInt();
        
        switch (choice) 
        {
            case 1:
                registerUser();
                break;
            case 2:
                loginUser();
                break;
            case 3:
                System.out.println("hy");
                break;
            default:
                System.out.println(" Please try again.");
                break;
        }
        
        scanner.close();
    }
    
    private static void registerUser() 
    {
        Scanner scanner = new Scanner(System.in);
        
        System.out.print("Enter username: ");
        String username = scanner.nextLine();
        System.out.print("Enter password: ");
        String password = scanner.nextLine();
        System.out.print("Enter email: ");
        String email = scanner.nextLine();
        
        try (Connection connection = DriverManager.getConnection("jdbc://localhost:3306/mydb")) 
        {
            String sql = "INSERT INTO users (username, password, email) VALUES (?, ?, ?)";
            PreparedStatement preparedStatement = connection.prepareStatement(sql);
            preparedStatement.setString(1, username);
            preparedStatement.setString(2, password);
            preparedStatement.setString(3, email);
            
            int rowsInserted = preparedStatement.executeUpdate();
            
            if (rowsInserted > 0) 
            {
                System.out.println("User registered successfully!");
            } else {
                System.out.println("User registration failed.");
            }
        } 
        catch (SQLException e) 
        {
            e.printStackTrace();
        }
    }
    
    private static void loginUser() 
    {
        Scanner scanner = new Scanner(System.in);
        
        System.out.print("Enter username: ");
        String username = scanner.nextLine();
        System.out.print("Enter password: ");
        String password = scanner.nextLine();
        
        try (Connection connection = DriverManager.getConnection("  jdbc://localhost:3306/mydb ")) 
        {
            String sql = "SELECT * from users whre username = ? and password = ?";
            PreparedStatement preparedStatement = connection.prepareStatement(sql);
            preparedStatement.setString(1, username);
            preparedStatement.setString(2, password);
            
            ResultSet resultSet = preparedStatement.executeQuery();
            
            if (resultSet.next()) 
            {
                System.out.println("Login successful!");
               
            } 
            else 
            {
                System.out.println("login failed. invalid ");
            }
        } 
        catch (SQLException e) 
        {
            e.printStackTrace();
        }
    }
}