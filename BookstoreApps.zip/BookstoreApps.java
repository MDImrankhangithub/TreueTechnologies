package onlineBookStore;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import onlineBookStore.mindrot.jbcrypt.BCrypt;

public class BookstoreApps {
    private static final String jdbc_url= "jdbc:mysql://localhost:3306/mydb";
    private static final String jdbc_username= "_username";
    private static final String jdbc_password = "password";

    public static void main(String[] args) {
        String username = "john_doe";
        String email = "john@example.com";
        String password = "password123";

        if (registerUser(username, email, password)) {
            System.out.println("User registration successful.");
        } else {
            System.out.println("User registration failed.");
        }
    }

    public static boolean registerUser(String username, String email, String password) 
    {
        try 
        {
            Connection connection = DriverManager.getConnection("jdbc:mysql://localhost/mydb");

         
            if (emailExists(connection, email)) 
            {
                System.out.println("User registration failed. Email already exists.");
                return false;
            }

           
            String hashedPassword = BCrypt.hashpw(password, BCrypt.gensalt());

            String insertQuery = "INSERT INTO users (username, email, password) VALUES (?, ?, ?)";
            PreparedStatement preparedStatement = connection.prepareStatement(insertQuery);
            preparedStatement.setString(1, username);
            preparedStatement.setString(2, email);
            preparedStatement.setString(3, hashedPassword);

            int rowsInserted = preparedStatement.executeUpdate();
            connection.close();

            return rowsInserted > 0;
        } catch (SQLException e) 
        {
            e.printStackTrace();
            return false;
        }
    }

    public static boolean emailExists(Connection connection, String email) throws SQLException {
        String query = "SELECT COUNT(*) FROM users WHERE email = ?";
        PreparedStatement preparedStatement = connection.prepareStatement(query);
        preparedStatement.setString(1, email);
        var result = preparedStatement.executeQuery();
        result.next();
        int count = result.getInt(1);
        return count > 0;
    }
}
