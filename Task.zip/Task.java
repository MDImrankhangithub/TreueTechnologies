package taskReminder;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

class Task {
    private String title;
    private String description;
    private boolean completed;

    public Task(String title, String description) 
    {
        this.title = title;
        this.description = description;
        this.completed = false;
    }

    

    public String getTitle()
    {
        return title;
    }

    public void setTitle(String title) 
    {
        this.title = title;
    }

    public String getDescription() 
    {
        return description;
    }

    public void setDescription(String description) 
    {
        this.description = description;
    }

    public boolean isCompleted() 
    {
    	
        return completed;
    }

    public void setCompleted(boolean completed)
    {
        this.completed = completed;
    }

    @Override
    public String toString() {
        return "Task: " + title + "\nDescription: " + description + "\nStatus: " + (completed ? "Completed" : "Incomplete");
    }
}

public class TaskManagerConsoleApp 
{
    private static List<Task> tasks = new ArrayList<>();
    private static Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {
        while (true) {
            System.out.println("\nTask Manager");
            System.out.println("1. Add Task");
            System.out.println("2. List Tasks");
            System.out.println("3. Mark Task as Completed");
            System.out.println("4. Quit");
            System.out.print("Enter your choice: ");

            int choice = scanner.nextInt();
            scanner.nextLine(); 

            switch (choice) {
                case 1:
                    addTask();
                    break;
                case 2:
                    listTasks();
                    break;
                case 3:
                    markTaskAsCompleted();
                    break;
                case 4:
                    System.out.println("Goodbye!");
                    scanner.close();
                    System.exit(0);
                    break;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }

    private static void addTask() 
    {
        System.out.print("Enter task title: ");
        String title = scanner.nextLine();
        System.out.print("Enter task description: ");
        String description = scanner.nextLine();

        Task task = new Task(title, description);
        tasks.add(task);

        System.out.println("Task added successfully.");
    }

    private static void listTasks() 
    {
        System.out.println("Tasks:");
        for (int i = 0; i < tasks.size(); i++) 
        {
            Task task = tasks.get(i);
            System.out.println((i + 1) + ". " + task);
        }
    }

    private static void markTaskAsCompleted() 
    {
        listTasks();
        System.out.print("Enter the task number to mark as completed: ");
        int taskNumber = scanner.nextInt() - 1;

        if (taskNumber >= 0 && taskNumber < tasks.size()) {
            Task task = tasks.get(taskNumber);
            task.setCompleted(true);
            System.out.println("Task marked as completed.");
        } else {
            System.out.println("Invalid task number.");
        }
    }
}
