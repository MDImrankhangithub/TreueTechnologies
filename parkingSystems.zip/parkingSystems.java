package onlineParkingSysteme;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

public class parkingSystems
{
    private static Connection connection;

    public static void main(String[] args)
    {
        try 
        {
           
            connection = DriverManager.getConnection("jdbc:mysql://localhost/mydb" );

          
            Scanner scanner = new Scanner(System.in);
            boolean running = true;

            while (running) {
                System.out.println("1. Register");
                System.out.println("2. Login");
                System.out.println("3. Exit");
                System.out.print("Choose an option: ");
                int choice = scanner.nextInt();
                scanner.nextLine(); 

                switch (choice) {
                    case 1:
                        registerUser(scanner);
                        break;
                    case 2:
                        login(scanner);
                        break;
                    case 3:
                        running = false;
                        break;
                    default:
                        System.out.println("Invalid option. Please try again.");
                        break;
                }
            }

            scanner.close();
        } catch (SQLException e)
        {
            e.printStackTrace();
        }
    }

    

    private static void registerUser(Scanner scanner) 
    {
        System.out.print("Enter username: ");
        String username = scanner.nextLine().trim();
        System.out.print("Enter password: ");
        String password = scanner.nextLine().trim();

     
        if (username.isEmpty() || password.isEmpty()) {
            System.out.println("Username and password cannot be empty.");
            return;
        }

        try (PreparedStatement insertStatement = connection.prepareStatement(
                "INSERT INTO users (username, password) VALUES (?, ?)")) 
        {
            insertStatement.setString(1, username);
            insertStatement.setString(2, password);
            int rowsAffected = insertStatement.executeUpdate();
            if (rowsAffected > 0) 
            {
                System.out.println("Registration successful.");
            }
            else 
            {
                System.out.println("Registration failed.");
            }
        } 
        catch (SQLException e)
        {
            System.out.println("Registration failed.");
        }
    }

    private static void login(Scanner scanner) 
    {
        System.out.print("Enter username: ");
        String username = scanner.nextLine().trim();
        System.out.print("Enter password: ");
        String password = scanner.nextLine().trim();

        try (PreparedStatement selectStatement = connection.prepareStatement(
                "SELECT password FROM users WHERE username = ?"))
        {
            selectStatement.setString(1, username);
            ResultSet resultSet = selectStatement.executeQuery();

            if (resultSet.next() && resultSet.getString("password").equals(password)) 
            {
                System.out.println("Login successful. Welcome, " + username + "!");
            } 
            else 
            {
                System.out.println("Login failed. Please check your username and password.");
            }
        } 
        catch (SQLException e) 
        {
            e.printStackTrace();
        }
    }
}
